/* ===========================================================
 * ro.js
 * Romanian translation for Trumbowyg
 * http://alex-d.github.com/Trumbowyg
 * ===========================================================
 * Author : Vladut Radulescu (pacMakaveli)
 *          Email: pacMakaveli90@gmail.com
 *          Twitter : @pacMakaveli90
 *          Website : creative-studio51.co.uk
 *          Github : https://github.com/pacMakaveli
 */

jQuery.trumbowyg.langs.ro = {
    viewHTML: 'Vizualizare HTML',

    formatting: 'Format',
    p: 'Paragraf',
    blockquote: 'Citație',
    code: 'Cod',
    header: 'Titlu',

    bold: 'Bold',
    italic: 'Italic',
    strikethrough: 'Tăiat',
    underline: 'Subliniat',

    strong: 'Puternic',
    em: 'Accentuat',
    del: 'Sterge',

    unorderedList: 'Lista dezordonată',
    orderedList: 'Liste ordonată',

    insertImage: 'Adăugare Imagine',
    insertVideo: 'Adăugare Video',
    link: 'Link',
    createLink: 'Crează link',
    unlink: 'Remover link',

    justifyLeft: 'Aliniază stânga',
    justifyCenter: 'Aliniază centru',
    justifyRight: 'Aliniază dreapta',
    justifyFull: 'Justificare',

    horizontalRule: 'Linie orizontală',

    fullscreen: 'Tot ecranul',

    close: 'Închide',

    submit: 'Procesează',
    reset: 'Resetează',

    required: 'Obligatoriu',
    description: 'Descriere',
    title: 'Titlu',
    text: 'Text'
};
